const express = require('express');
const router = express.Router();
const { 
  getAllAttendance, 
  getLessonAttendance, 
  getStudentAttendance, 
  getAttendance, 
  createAttendance, 
  updateAttendance, 
  deleteAttendance,
  createGroupAttendance
} = require('../controllers/attendanceController');
const { protect, authorize } = require('../middleware/auth');

// Protect all routes
router.use(protect);

// Routes with specific authorization
router.route('/')
  .get(authorize('teacher', 'admin'), getAllAttendance)
  .post(authorize('teacher', 'admin'), createAttendance);

router.route('/lesson/:lessonId')
  .get(authorize('teacher', 'admin'), getLessonAttendance);

router.route('/student/:studentId')
  .get(authorize('student', 'teacher', 'admin'), getStudentAttendance);

router.route('/lesson/:lessonId/group/:groupId')
  .post(authorize('teacher', 'admin'), createGroupAttendance);

router.route('/:id')
  .get(authorize('student', 'teacher', 'admin'), getAttendance)
  .put(authorize('teacher', 'admin'), updateAttendance)
  .delete(authorize('admin'), deleteAttendance);

module.exports = router;
