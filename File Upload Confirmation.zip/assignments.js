const express = require('express');
const router = express.Router();
const { 
  getAssignments, 
  getGroupAssignments, 
  getAssignment, 
  createAssignment, 
  updateAssignment, 
  deleteAssignment,
  getAssignmentSubmissions,
  submitAssignment,
  gradeSubmission
} = require('../controllers/assignmentController');
const { protect, authorize } = require('../middleware/auth');

// Protect all routes
router.use(protect);

// Routes with specific authorization
router.route('/')
  .get(authorize('student', 'teacher', 'admin'), getAssignments)
  .post(authorize('teacher', 'admin'), createAssignment);

router.route('/group/:groupId')
  .get(authorize('student', 'teacher', 'admin'), getGroupAssignments);

router.route('/:id')
  .get(authorize('student', 'teacher', 'admin'), getAssignment)
  .put(authorize('teacher', 'admin'), updateAssignment)
  .delete(authorize('teacher', 'admin'), deleteAssignment);

router.route('/:id/submissions')
  .get(authorize('teacher', 'admin'), getAssignmentSubmissions);

router.route('/:id/submit')
  .post(authorize('student'), submitAssignment);

router.route('/submissions/:id/grade')
  .put(authorize('teacher', 'admin'), gradeSubmission);

module.exports = router;
