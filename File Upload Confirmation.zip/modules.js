const express = require('express');
const router = express.Router();
const { 
  getModules, 
  getModule, 
  createModule, 
  updateModule, 
  deleteModule 
} = require('../controllers/moduleController');
const { protect, authorize } = require('../middleware/auth');

// Protect all routes
router.use(protect);

// Routes with specific authorization
router.route('/')
  .get(authorize('student', 'teacher', 'admin'), getModules)
  .post(authorize('admin'), createModule);

router.route('/:id')
  .get(authorize('student', 'teacher', 'admin'), getModule)
  .put(authorize('admin'), updateModule)
  .delete(authorize('admin'), deleteModule);

module.exports = router;
