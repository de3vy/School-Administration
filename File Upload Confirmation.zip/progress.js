const express = require('express');
const router = express.Router();
const { 
  getAllProgress, 
  getStudentProgress, 
  getModuleProgress, 
  getProgress, 
  createProgress, 
  updateProgress, 
  deleteProgress 
} = require('../controllers/progressController');
const { protect, authorize } = require('../middleware/auth');

// Protect all routes
router.use(protect);

// Routes with specific authorization
router.route('/')
  .get(authorize('teacher', 'admin'), getAllProgress)
  .post(authorize('teacher', 'admin'), createProgress);

router.route('/student/:studentId')
  .get(authorize('student', 'teacher', 'admin'), getStudentProgress);

router.route('/module/:moduleId')
  .get(authorize('teacher', 'admin'), getModuleProgress);

router.route('/:id')
  .get(authorize('student', 'teacher', 'admin'), getProgress)
  .put(authorize('teacher', 'admin'), updateProgress)
  .delete(authorize('admin'), deleteProgress);

module.exports = router;
